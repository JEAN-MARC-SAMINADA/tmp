export class Product {
    id:number;
    name:string;
    src:string;
    info:string;
    price:number;
}