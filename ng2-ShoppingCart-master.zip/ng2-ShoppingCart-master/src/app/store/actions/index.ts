import { CartAction } from './cart.actions';
import { ProfileAction } from './profile.actions';

export const ACTIONS = [
  CartAction,
  ProfileAction
]