import { Product } from '../../models/Product';

interface ICartState {
  products: Array<Product>;
}

export default ICartState;