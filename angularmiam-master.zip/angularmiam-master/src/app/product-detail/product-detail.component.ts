import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ProductService } from '../services/product.service';
import { Product } from '../models/product';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styles: []
})
export class ProductDetailComponent implements OnInit {
  product: Product;

  constructor(private productService: ProductService,
              private route: ActivatedRoute) { }

  ngOnInit() {
    // Récupère le slug dans l'URL.
    const slug = this.route.snapshot.paramMap.get('slug');
    // Charge le produit correspondant avec le service.
    this.productService.getProductBySlug(slug)
      .subscribe(data => this.product = {...data, photo: enlargeImage(data.photo)});
  }

}

function enlargeImage(imagePath: string): string {
  return imagePath.replace('h_240,w_318', 'h_720,w_954');
}
