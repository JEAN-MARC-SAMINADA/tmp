import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { Product, ProductType } from '../models/product';
import { SearchService } from '../search.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styles: []
})
export class ProductListComponent implements OnInit {
  products: Product[];

  starters: Product[];
  mainCourses: Product[];
  desserts: Product[];

  constructor(private productService: ProductService,
              private searchService: SearchService) {

              }

  ngOnInit() {
    this.productService.getProducts()
      .subscribe(data => {
        this.products = data;
        this.starters = this.products.filter(p => p.type === ProductType.Entree);
        this.mainCourses = this.products.filter(p => p.type === ProductType.Plat);
        this.desserts = this.products.filter(p => p.type === ProductType.Dessert);
      });
    this.searchService.subject.subscribe(searchedText => {
      const filteredProducts = this.products.filter(p => p.name.toLowerCase().indexOf(searchedText.toLowerCase()) !== -1);
      this.starters = filteredProducts.filter(p => p.type === ProductType.Entree);
      this.mainCourses = filteredProducts.filter(p => p.type === ProductType.Plat);
      this.desserts = filteredProducts.filter(p => p.type === ProductType.Dessert);
    });
  }

}
