import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import { Product } from '../models/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient,
              @Inject('BACKEND_URL') private baseUrl: string) { }

  /**
   * Load the list of all products.
   */
  getProducts(): Observable<Product[]> {
    return this.http.get(`${this.baseUrl}/products`)
      // Re-hydrate
      .pipe(
        map((productArray: any[]) => productArray.map(productData => new Product(productData)))
      );
  }

  /**
   * Load the given product ALONG WITH its questions.
   */
  getProduct(productId: number): Observable<Product> {
    return this.http.get(`${this.baseUrl}/products/${productId}`)
      .pipe(
        map((productData: any) => new Product(productData)),
      );
  }

  getProductBySlug(slug: string): Observable<Product> {
    return this.http.get(`${this.baseUrl}/products?slug=${slug}`)
    .pipe(
      map(results => results[0]),  // garde le 1er objet dans la liste des obj renvoyés
      map((productData: any) => new Product(productData)),
    );
  }

}
