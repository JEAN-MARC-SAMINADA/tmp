import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FoodcheriService {

  constructor(private http: HttpClient) { }

  processFoodCheri(): Observable<any> {
    return this.http.get('/assets/foodcheriProducts.json')
      .pipe(
        map((data: any) => data.page.productSections),
        map(sections => sections.filter(section => isEntreePlatDessert(section))),
        tap(console.log),
        map((sections: any[]) => {
          const products = [];
          for (const section of sections) {
            for (const pub of section.publications) {
              products.push({
                id: pub.id_product,
                name: pub.title,
                description: getFakeDescription(),
                photo: 'https://res.cloudinary.com/eatzy/image/upload/c_fill,h_240,w_318/' + pub.picture,
                photoAlt: pub.alt,
                price: pub.price,
                type: pub.product_type_name,
                stock: 10,
                // Bonus info
                tags: pub.tags,
                nutritional_informations: pub.nutritional_informations,
                slug: pub.slug,
              });
            }
          }
          return products;
        })
      );
  }

}

function isEntreePlatDessert(section): boolean {
  return section.title === 'Entrées' || section.title === 'Plats' || section.title === 'Desserts';
}

function getFakeDescription() {
  return `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et ullamcorper justo, eget mollis erat. Donec et justo at neque dictum malesuada. Duis dapibus lobortis elit et lobortis. Integer mollis vitae sem vel maximus. Curabitur ultrices tincidunt suscipit. Nullam feugiat dolor in turpis pharetra, nec interdum metus tincidunt. Etiam eget mi venenatis, porta risus id, accumsan ex. Integer elementum augue eu arcu finibus, eu malesuada nisi euismod. Nunc sed mi a purus faucibus ultricies. Duis at feugiat nibh. Ut maximus vitae felis id faucibus.

  Vivamus et venenatis mauris, non interdum eros. Vestibulum efficitur convallis gravida. Morbi laoreet nulla in posuere varius. Etiam rutrum sem in pharetra pharetra. Cras at mi dolor. In sit amet vulputate ex, a pharetra felis. Integer aliquam consectetur purus, vel pharetra felis egestas ut. Donec pellentesque faucibus felis, sit amet dapibus velit sodales convallis. Donec iaculis elit eu efficitur volutpat. Nullam ullamcorper sapien luctus lacus porta consectetur. Duis pellentesque, risus vel aliquam condimentum, massa ligula sollicitudin turpis, at vestibulum urna augue vitae felis. Mauris congue justo nec augue posuere molestie. Duis sodales ultricies tortor vel tristique.

  Morbi et tincidunt enim, nec sollicitudin neque. Sed ipsum erat, vehicula vitae sagittis sit amet, tincidunt sit amet mauris. Integer non nulla sed diam mollis ultricies. Nulla in purus tempor, finibus nisi a, egestas est. Phasellus at tellus non nunc fringilla lacinia vitae non neque. Nulla facilisi. Maecenas semper consequat semper. Nunc ut ligula in dolor dapibus ullamcorper vitae vel tortor. Pellentesque vel ex in odio viverra pulvinar. Quisque pharetra, leo et efficitur consectetur, arcu urna tincidunt diam, quis accumsan augue odio in tellus.`;
}
