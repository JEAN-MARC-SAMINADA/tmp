import { Component } from '@angular/core';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-cart-icon',
  templateUrl: './cart-icon.component.html',
  styleUrls: ['./cart-icon.component.css']
})
export class CartIconComponent {

  constructor(private cart: CartService) { }

  getTotalProducts() {
    return this.cart.totalProducts;
  }

}
