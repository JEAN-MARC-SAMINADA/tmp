import { Component, OnInit } from '@angular/core';
import { SearchService } from '../search.service';

@Component({
  selector: 'app-order-info',
  templateUrl: './order-info.component.html',
  styles: []
})
export class OrderInfoComponent implements OnInit {

  constructor(private searchService: SearchService) {

  }

  ngOnInit() {
  }

  search(searchedText: string) {
    console.log('search', searchedText);
    this.searchService.subject.next(searchedText);
  }

}
