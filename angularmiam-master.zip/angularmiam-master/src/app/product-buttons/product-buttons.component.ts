import { Component, OnInit, Input } from '@angular/core';
import { CartService } from '../services/cart.service';
import { Product } from '../models/product';

@Component({
  selector: 'app-product-buttons',
  templateUrl: './product-buttons.component.html',
  styleUrls: ['./product-buttons.component.css'],
})
export class ProductButtonsComponent implements OnInit {
  @Input() numProducts: number;
  @Input() product: Product;
  @Input() size: 'small' | 'medium' | 'large';

  constructor(private cart: CartService) { }

  ngOnInit() {
  }

  add(event: Event) {
    event.stopPropagation();
    this.numProducts++;
    this.cart.addProduct(this.product);
  }

  remove(event: Event) {
    event.stopPropagation();
    this.numProducts--;
    this.cart.removeProduct(this.product);
  }

}
